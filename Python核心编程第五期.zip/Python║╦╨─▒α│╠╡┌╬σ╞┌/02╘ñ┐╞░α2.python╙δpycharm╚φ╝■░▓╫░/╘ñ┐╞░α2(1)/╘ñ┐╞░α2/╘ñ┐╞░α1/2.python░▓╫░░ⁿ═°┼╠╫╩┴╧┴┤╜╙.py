# @Author : 大海
# @File : 2.python安装包网盘资料链接.py
'''
安装python和pycharm文档教程 这里面需要先安装 （ typora-setup-x64  软件   就是markdown文档的软件 ）
先python     后pycharm
markdown文档
    链接：https://pan.baidu.com/s/1vIid0nH5S4RggQkpHdIeZw
    提取码：9wef
    --来自百度网盘超级会员V3的分享
pdf文档
    链接：https://pan.baidu.com/s/1_4br7GGcN71g2JDkAj6PMw
    提取码：z7ka
    --来自百度网盘超级会员V4的分享



安装python和pycharm视频教程   （ 完全一步步进行教学 1 到 5 个视频    ）

链接：https://pan.baidu.com/s/1cuMXdfR3av_6ZNaJyEIVUQ
提取码：blit
--来自百度网盘超级会员V3的分享



笔记安装包和截图软件   （  对学习效率有很大帮助  ）

makedown安装包，截图软件Snipaste_2021-12-03_21-35-23.png，学习方法文档，有道词典

链接：https://pan.baidu.com/s/1NmjzxMaj4MpYeXyJh00lAw
提取码：kvbu
--来自百度网盘超级会员V3的分享


mac  python和pycharm安装包  （ 其他步骤一样，英文单词的位置稍微改了下位置，但是视频是有标注的  ）

链接：https://pan.baidu.com/s/1dYOs69oVA85as32U22nusw
提取码：qyut
--来自百度网盘超级会员V3的分享
'''

# l = [1,2,3]
# #    0,1,2
# print(l[2])
# # print(l)
print('hello world')





