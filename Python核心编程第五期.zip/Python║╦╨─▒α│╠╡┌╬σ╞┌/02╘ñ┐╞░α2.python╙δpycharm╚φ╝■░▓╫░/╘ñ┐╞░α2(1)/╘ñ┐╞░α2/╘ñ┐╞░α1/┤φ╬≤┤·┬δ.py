# @Author : 大海
# @File : 错误代码.py2

L = [1,2,3]
# 索引
#    0,1,2
print(L[2])