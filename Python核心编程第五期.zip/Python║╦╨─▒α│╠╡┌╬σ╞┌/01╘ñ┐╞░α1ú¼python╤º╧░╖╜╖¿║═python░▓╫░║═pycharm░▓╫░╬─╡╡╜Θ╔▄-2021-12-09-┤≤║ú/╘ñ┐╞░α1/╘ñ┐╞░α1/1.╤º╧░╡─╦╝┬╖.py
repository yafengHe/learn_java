# @Author : 大海
# @File : 1.学习的思路.py
'''
1.百度网盘
    1.1 现在下载一个百度网盘软件
    1.2 打开链接，输入提取码 点击下载
2.关于rar后缀的解压文档
    需要下载一个解压软件winrar
3.typora软件安装
    可以打开md后缀的文档，就是markdown文档

'''

# ctrl+/
# dasdasdas
# dasdasdas
# dasdasdas
# dasdasdas
# dasdasdas

